package org.elsys.ufg;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UfgApplicationTests {

	@Test
	void contextLoads() {
	}

}
